package com.example.campusevent

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Este composable crea la lista desplazable (LazyColumn)
@Composable
fun ListaEventos(lista: List<Evento>, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp), // Margen alrededor de la lista
        verticalArrangement = Arrangement.spacedBy(12.dp) // Espacio entre tarjetas
    ) {
        // Usamos la key para que Compose no se confunda si hacemos scroll
        items(lista, key = { it.id }) { evento ->
            TarjetaEvento(evento = evento)
        }
    }
}