package com.example.campusevent

// Defino el molde (data class) para los eventos del campus
data class Evento(
    val id: Int, // Identificador del evento
    val titulo: String, // Nombre del taller o conferencia
    val categoria: String, // A qué área pertenece (ej. Programación)
    val fecha: String, // Cuándo se llevará a cabo
    val descripcion: String, // De qué trata el evento
    val imagen: Int // El recurso de imagen que se mostrará
)