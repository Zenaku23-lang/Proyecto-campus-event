package com.example.campusevent

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip

// Este composable dibuja cada tarjeta individual de la lista
@Composable
fun TarjetaEvento(evento: Evento, modifier: Modifier = Modifier) {
    // Estados locales para que cada tarjeta se abra y marque favorito de forma independiente
    var abierto by remember { mutableStateOf(false) }
    var esFavorito by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            // Animación para que el cambio de tamaño sea fluido
            .animateContentSize(
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Fila superior: imagen, título, categoría y el corazón
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = evento.imagen),
                    contentDescription = evento.titulo,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(MaterialTheme.shapes.medium)
                )
                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = evento.titulo,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = evento.categoria,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Botón del corazón: cambia entre relleno y contorno
                IconButton(onClick = { esFavorito = !esFavorito }) {
                    Icon(
                        imageVector = if (esFavorito) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorito",
                        tint = if (esFavorito) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Si el estado 'abierto' es true, mostramos los detalles extra
            if (abierto) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = evento.fecha,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = evento.descripcion,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // Botón inferior con la flechita para expandir/colapsar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { abierto = !abierto }) {
                    Text(text = if (abierto) "Ocultar detalles" else "Ver detalles")
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (abierto) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = "Expandir"
                    )
                }
            }
        }
    }
}