package com.example.campusevent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.campusevent.ui.theme.CampusEventTheme

// Clase principal de la aplicación
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Aplicamos el tema de la app
            CampusEventTheme {
                PantallaPrincipal()
            }
        }
    }
}

// Este es el esqueleto de la pantalla (Scaffold con TopAppBar)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaPrincipal() {
    Scaffold(
        topBar = {
            // Barra superior con el título de la app
            TopAppBar(
                title = { Text("Campus Events") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        // Llamamos a nuestra lista y le pasamos los datos
        ListaEventos(
            lista = DatosEventos().obtenerEventos(),
            modifier = Modifier.padding(padding)
        )
    }
}
@Preview(showBackground = true)
@Composable
fun PreviewCampusEvents() {
    CampusEventTheme {
        PantallaPrincipal()
    }
}