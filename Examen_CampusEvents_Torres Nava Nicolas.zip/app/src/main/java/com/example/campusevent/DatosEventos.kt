package com.example.campusevent

// Esta clase se encarga de proveer la información a la pantalla
class DatosEventos {
    // Función que retorna una lista con 5 eventos de prueba
    fun obtenerEventos(): List<Evento> {
        return listOf(
            Evento(
                id = 1,
                titulo = "Taller de Kotlin desde Cero",
                categoria = "Programación",
                fecha = "Lunes 17 de Marzo, 10:00 a.m.",
                descripcion = "Aprende las bases de Kotlin: variables, funciones y clases. Trae tu laptop, habrá práctica en el Laboratorio 3.",
                imagen = android.R.drawable.ic_menu_gallery // Imagen genérica de Android
            ),
            Evento(
                id = 2,
                titulo = "Primer acercamiento a Jetpack Compose",
                categoria = "Desarrollo Móvil",
                fecha = "Miércoles 19 de Marzo, 4:00 p.m.",
                descripcion = "Veremos cómo crear interfaces declarativas en Android. Ideal si ya sabes lo básico de programación.",
                imagen = android.R.drawable.ic_menu_camera
            ),
            Evento(
                id = 3,
                titulo = "Clase extra: Git y GitHub",
                categoria = "Herramientas",
                fecha = "Viernes 21 de Marzo, 9:00 a.m.",
                descripcion = "Refuerza el control de versiones para tus proyectos finales. Veremos ramas, commits y cómo subir a la nube.",
                imagen = android.R.drawable.ic_menu_manage
            ),
            Evento(
                id = 4,
                titulo = "Conferencia: IA en el aula",
                categoria = "Conferencia",
                fecha = "Martes 25 de Marzo, 12:00 p.m.",
                descripcion = "Charla sobre cómo la inteligencia artificial está cambiando la forma en que estudiamos y programamos.",
                imagen = android.R.drawable.ic_menu_compass
            ),
            Evento(
                id = 5,
                titulo = "Hackathon de Primavera",
                categoria = "Competencia",
                fecha = "Sábado 29 de Marzo, 8:00 a.m.",
                descripcion = "48 horas seguidas de código. Forma tu equipo, resuelve el reto y compite por premios y créditos extracurriculares.",
                imagen = android.R.drawable.ic_menu_slideshow
            )
        )
    }
}